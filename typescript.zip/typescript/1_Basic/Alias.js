var mes;
mes = "God Is Great.";
console.log(mes);
var input;
input = 1; // valid
input = "God Is Great."; // valid
// input = false; // Compiler error
